---
lifeops_id: "recipe-1"
type: "recipe"
version: 4
updated_at: "2026-08-22T08:00:00.000Z"
title: "Synthetic recipe fixture"
tags:
  - "fixture"
---
# Synthetic recipe fixture

No private note body is included.